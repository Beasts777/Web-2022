package org.csu.mypetstore.web.servlets;

import org.csu.mypetstore.service.CatalogService;
import org.csu.mypetstore.service.SearchService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AddServlet extends HttpServlet {
    //category界面
    public static final String VIEW_CATEGORY = "/WEB-INF/jsp/catalog/Category.jsp";
    SearchService service;
    CatalogService service2;
    public AddServlet(){
        service=new SearchService();
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/plain;charset=utf-8");
        req.setCharacterEncoding("utf-8");
        String productName=req.getParameter("productName");
        String productId=service.getProductId(productName);
        resp.getWriter().write(productId);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
