package org.csu.mypetstore.web.servlets;

import com.mysql.cj.Session;
import org.csu.mypetstore.domain.Account;
import org.csu.mypetstore.domain.Order;
import org.csu.mypetstore.service.OrderService;

import javax.print.attribute.standard.OrientationRequested;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

public class OrderServlet extends HttpServlet {
    public static final String VIEW_ORDERS="/WEB-INF/jsp/order/ListOrders.jsp";
    private OrderService service;
    public OrderServlet(){
        service=new OrderService();
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session= req.getSession();
        Account account =(Account) session.getAttribute("account");
        List<Order> orderlist=service.getOrdersByUsername(account.getUsername());
        session.setAttribute("orderList",orderlist);
        req.getRequestDispatcher(VIEW_ORDERS).forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
