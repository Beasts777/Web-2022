package org.csu.mypetstore.persistence;

import org.csu.mypetstore.domain.ViewItemLog;

import java.util.Date;
import java.util.List;

public interface ViewItemLogDAO {
    public void insertLog(ViewItemLog viewItemLog);
    public List<ViewItemLog> getLog(String username);
    public void updateCountAndDate(String username,String itemId);
}
