package org.csu.mypetstore.persistence;

import org.csu.mypetstore.domain.Sequence;

public interface SequenceDAO {
    public Sequence getSequence(Sequence sequence);
    public void updateSequence(Sequence sequence);
}
