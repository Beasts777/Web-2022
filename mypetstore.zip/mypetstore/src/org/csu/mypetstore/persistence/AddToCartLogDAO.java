package org.csu.mypetstore.persistence;

import org.csu.mypetstore.domain.AddToCartLog;

import java.util.Date;
import java.util.List;

public interface AddToCartLogDAO {
    public void insertLog(AddToCartLog addToCartLog);
    public List<AddToCartLog> getLog(String username);
    public void updateCountAndDate(String username,String itemId);
}
