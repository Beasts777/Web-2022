package org.csu.mypetstore.persistence.impl;

import org.csu.mypetstore.domain.Account;
import org.csu.mypetstore.persistence.AccountDAO;

public class AccountDAOImpl extends BaseDAO<Account> implements AccountDAO {

    public static final String GET_ACCOUNT_BY_USERNAME = "SELECT * FROM ACCOUNT WHERE username = ?";
    public static final String GET_ACCOUNT_BY_USERNAME_AND_PASSWORD = "SELECT * FROM `account` WHERE username = ? AND `password` = ?";
    public static final String INSERT_ACCOUNT = "INSERT INTO `account`(username,`password`) VALUES(?,?)";
    public static final String INSERT_PROFILE = "";
    public static final String INSERT_SIGN_ON = "";
    public static final String UPDATE_ACCOUNT = "UPDATE `account` SET `password`=?,email=?,firstname=?,lastname=?,address1=?,address2=?,city=?,state=?,zip=?,country=?,phone=? WHERE username=?";
    public static final String UPDATE_PROFILE = "";
    public static final String UPDATE_SIGN_ON = "";

    @Override
    public void updateAccount(Account account) {
        update(UPDATE_ACCOUNT,account.getPassword(),account.getEmail(),account.getFirstName(),account.getLastName(),
                account.getAddress1(),account.getAddress2(),account.getCity(),account.getState(),account.getZip(),
                account.getCountry(),account.getPhone(),account.getUsername());
    }


    @Override
    public Account getAccountByUsername(String username) {
        return querySingle(GET_ACCOUNT_BY_USERNAME,Account.class,username);
    }

    @Override
    public Account getAccountByUsernameAndPassword(Account account) {
        return querySingle(GET_ACCOUNT_BY_USERNAME_AND_PASSWORD,Account.class,account.getUsername(),account.getPassword());
    }

    @Override
    public void insertAccount(Account account) {
        update(INSERT_ACCOUNT,account.getUsername(),account.getPassword());
//        update(INSERT_ACCOUNT,account.getUsername(),account.getPassword(),account.getEmail(),account.getFirstName(),
//                account.getLastName(), account.getStatus(),account.getAddress1(),account.getAddress2(),
//                account.getCity(),account.getState(),account.getZip(),account.getCountry(),account.getPhone());

//        update(INSERT_ACCOUNT,account.getUsername(),account.getPassword(),account.getEmail(),account.getFirstName(),account.getLastName(),
//                account.getStatus(),account.getAddress1(),account.getAddress2(),account.getCity(),account.getState(),account.getZip(),account.getCountry(),
//                account.getPhone(),account.getFavouriteCategoryId(),account.getLanguagePreference(),account, account.isListOption(),account.isBannerOption(),
//                account.getBannerName()
//        );
    }

    @Override
    public void insertProfile(Account account) {
        update(INSERT_PROFILE,account.getLanguagePreference(),account.getFavouriteCategoryId(),account.isListOption(),
                account.isBannerOption(),account.getUsername());
    }


    //以下为账号的偏好设置，在实际项目中没有应用
    @Override
    public void insertSignon(Account account) {
        update(INSERT_ACCOUNT,account.getUsername(),account.getPassword());
    }

    @Override
    public void updateProfile(Account account) {

    }

    @Override
    public void updateSignon(Account account) {

    }
}
