package org.csu.mypetstore.persistence.impl;

import org.csu.mypetstore.domain.ViewItemLog;
import org.csu.mypetstore.persistence.ViewItemLogDAO;

import java.util.Date;
import java.util.List;

public class ViewItemLogDAOImpl extends BaseDAO<ViewItemLog> implements ViewItemLogDAO {

    public static final String INSERT_LOG = "INSERT INTO log_viewitem (username,itemid,descn,listprice,`date`,`count`) VALUES (?,?,?,?,?,?)";
    public static final String GET_LOG = "SELECT *  FROM log_viewitem WHERE username = ? order by `date` desc";
    public static final String UPDATE_COUNT_AND_DATE = "UPDATE log_viewitem SET `count` = `count`+1, `date` = ? WHERE username = ? AND itemid = ?";

    @Override
    public void insertLog(ViewItemLog viewItemLog) {
        update(INSERT_LOG,viewItemLog.getUsername(),viewItemLog.getItemId(),viewItemLog.getDescn(),viewItemLog.getListPrice(),viewItemLog.getDate(),viewItemLog.getCount());
    }

    @Override
    public List<ViewItemLog> getLog(String username) {
        return queryMulti(GET_LOG,ViewItemLog.class,username);
    }

    @Override
    public void updateCountAndDate(String username,String itemId) {
        update(UPDATE_COUNT_AND_DATE,new Date(),username,itemId);
    }
}
