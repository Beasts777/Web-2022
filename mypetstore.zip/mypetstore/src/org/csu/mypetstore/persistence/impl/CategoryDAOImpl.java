package org.csu.mypetstore.persistence.impl;

import org.csu.mypetstore.domain.Category;
import org.csu.mypetstore.persistence.CategoryDAO;

import java.util.List;

public class CategoryDAOImpl extends BaseDAO<Category> implements CategoryDAO {
    public static final String GET_CATEGORY_LIST = "SELECT CATID AS categoryId, NAME, DESCN AS description FROM CATEGORY";
    public static final String GET_CATEGORY = "SELECT CATID AS categoryId, NAME, DESCN AS description FROM CATEGORY WHERE CATID = ?";

    @Override
    public List<Category> getCategoryList() {
        return queryMulti(GET_CATEGORY_LIST,Category.class);
    }

    @Override
    public Category getCategory(String categoryId) {
        return querySingle(GET_CATEGORY,Category.class,categoryId);
    }
}
