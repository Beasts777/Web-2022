package org.csu.mypetstore.persistence.impl;

import org.csu.mypetstore.domain.Sequence;
import org.csu.mypetstore.persistence.SequenceDAO;

public class SequenceDAOImpl extends BaseDAO<Sequence> implements SequenceDAO {
    public static final String GET_SEQUENCE = "SELECT * FROM sequence WHERE `name` = ?";
    public static final String UPDATE_SEQUENCE = "UPDATE sequence SET nextid = ? WHERE `name` = ?";

    @Override
    public Sequence getSequence(Sequence sequence) {
        return querySingle(GET_SEQUENCE,Sequence.class,sequence.getName());
    }

    @Override
    public void updateSequence(Sequence sequence) {
        update(UPDATE_SEQUENCE,sequence.getNextId(),sequence.getName());
    }
}
