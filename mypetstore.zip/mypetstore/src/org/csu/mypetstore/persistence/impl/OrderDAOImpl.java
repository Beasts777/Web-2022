package org.csu.mypetstore.persistence.impl;

import org.csu.mypetstore.domain.Order;
import org.csu.mypetstore.persistence.OrderDAO;

import java.util.List;

public class OrderDAOImpl extends BaseDAO<Order> implements OrderDAO {
    public static final String GET_ORDER_BY_USERNAME = "SELECT * FROM orders WHERE username = ?";
    public static final String GET_ORDER = "SELECT * FROM orders WHERE orderid = ?";
    public static final String INSERT_ORDER = "INSERT INTO orders VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    public static final String INSERT_ORDER_STATUS = "";


    @Override
    public List<Order> getOrdersByUsername(String username) {
        return queryMulti(GET_ORDER_BY_USERNAME,Order.class,username);
    }

    @Override
    public Order getOrder(int orderId) {
        return querySingle(GET_ORDER,Order.class,orderId);
    }

    @Override
    public void insertOrder(Order order) {
        update(INSERT_ORDER,order.getOrderId(),order.getUsername(),order.getOrderDate(),order.getShipAddress1(),order.getShipAddress2(),order.getShipCity(),order.getShipState(),order.getShipZip(),order.getShipCountry(),order.getBillAddress1(),order.getBillAddress2(),order.getBillCity(),order.getBillState(),order.getBillZip(),order.getBillCountry(),order.getCourier(),order.getTotalPrice(),order.getBillToFirstName(),order.getBillToLastName(),order.getShipToFirstName(),order.getBillToLastName(),order.getCreditCard(),order.getExpiryDate(),order.getCardType(),order.getLocale());
    }

    @Override
    public void insertOrderStatus(Order order) {

    }
}
