package org.csu.mypetstore.persistence.impl;

import org.csu.mypetstore.domain.Product;
import org.csu.mypetstore.persistence.ProductDAO;

import java.util.List;

public class ProductDAOImpl extends BaseDAO<Product> implements ProductDAO {

    public static final String GET_PRODUCT_LIST_BY_CATEGORY = "SELECT PRODUCTID,NAME,DESCN as description,CATEGORY as categoryId FROM PRODUCT WHERE CATEGORY = ?";
    public static final String GET_PRODUCT_BY_ID = "SELECT PRODUCTID,CATEGORY as categoryId,NAME,DESCN as description FROM PRODUCT WHERE PRODUCTID = ?";
    public static final String SEARCH_PRODUCT_LIST_BY_KEYWORDS = "select PRODUCTID,NAME,DESCN as description,CATEGORY as categoryId from PRODUCT WHERE lower(name) like ?";

    @Override
    public List<Product> getProductListByCategory(String categoryId) {
        return queryMulti(GET_PRODUCT_LIST_BY_CATEGORY,Product.class,categoryId);
    }

    @Override
    public Product getProduct(String productId) {
        return querySingle(GET_PRODUCT_BY_ID,Product.class,productId);
    }

    @Override
    public List<Product> searchProductList(String keywords) {
        return queryMulti(SEARCH_PRODUCT_LIST_BY_KEYWORDS,Product.class,keywords);
    }
}
