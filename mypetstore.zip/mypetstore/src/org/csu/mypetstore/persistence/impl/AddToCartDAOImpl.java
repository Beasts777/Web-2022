package org.csu.mypetstore.persistence.impl;

import org.csu.mypetstore.domain.AddToCartLog;
import org.csu.mypetstore.persistence.AddToCartLogDAO;

import java.util.Date;
import java.util.List;

public class AddToCartDAOImpl extends BaseDAO<AddToCartLog> implements AddToCartLogDAO {

    public static final String INSERT_LOG = "INSERT INTO log_addtocart (username,itemid,descn,listprice,`date`,`count`) VALUES (?,?,?,?,?,?)";
    public static final String GET_LOG = "SELECT * FROM log_addtocart WHERE username = ? order by `date` desc";
    public static final String UPDATE_COUNT_AND_DATE = "UPDATE log_addtocart SET `count` = `count`+1, `date` = ? WHERE username = ? AND itemid = ?";

    @Override
    public void insertLog(AddToCartLog addToCartLog) {
        update(INSERT_LOG,addToCartLog.getUsername(),addToCartLog.getItemId(),addToCartLog.getDescn(),addToCartLog.getListPrice(),addToCartLog.getDate(),addToCartLog.getCount());
    }

    @Override
    public List<AddToCartLog> getLog(String username) {
        return queryMulti(GET_LOG,AddToCartLog.class,username);
    }

    @Override
    public void updateCountAndDate(String username,String itemId) {
        update(UPDATE_COUNT_AND_DATE,new Date(),username,itemId);
    }
}
