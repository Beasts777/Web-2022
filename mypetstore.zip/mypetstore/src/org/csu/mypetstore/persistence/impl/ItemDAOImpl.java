package org.csu.mypetstore.persistence.impl;

import org.csu.mypetstore.domain.Item;
import org.csu.mypetstore.persistence.ItemDAO;

import java.util.List;
import java.util.Map;

public class ItemDAOImpl extends BaseDAO<Item> implements ItemDAO {
//    public static final String UPDATE_INVENTORY_QUANTITY = "UPDATE INVENTORY SET QTY = QTY - ? WHERE ITEMID = ?";
    public static final String GET_INVENTORY_QUANTITY_BY_ITEM_ID = "SELECT quantity AS value FROM INVENTORY WHERE ITEMID = ?";
    public static final String GET_ITEM_LIST_BY_PRODUCT = "SELECT * FROM item A,inventory B WHERE A.productid = ? AND A.itemid = B.itemid";
    public static final String GET_ITEM_BY_ITEM_ID = "SELECT * FROM item A,inventory B WHERE A.itemid = ? AND A.itemid = B.itemid";

    @Override
    public void updateInventoryQuantity(Map<String, Object> param) {
//        update(UPDATE_INVENTORY_QUANTITY,Item.class,param);
    }

    @Override
    public int getInventoryQuantity(String itemId) {
        return (int)queryScalar(GET_INVENTORY_QUANTITY_BY_ITEM_ID,itemId);
    }

    @Override
    public List<Item> getItemListByProduct(String productId) {
        return queryMulti(GET_ITEM_LIST_BY_PRODUCT,Item.class,productId);
    }

    @Override
    public Item getItem(String itemId) {
        return querySingle(GET_ITEM_BY_ITEM_ID,Item.class,itemId);
    }
}
