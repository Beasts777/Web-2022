package org.csu.mypetstore.persistence;

import org.csu.mypetstore.domain.Account;
import org.csu.mypetstore.domain.Cart;
import org.csu.mypetstore.domain.CartItem;

import java.util.List;

public interface CartItemDAO {
    public List<CartItem> getCartItemByAccount(Account account);

    public void clearCart(Account account);

    public void insertCartItem(CartItem cartItem);

    public void increaseCartItemQuantity(CartItem cartItem);

    public void removeCartItem(CartItem cartItem);

    public void updateCartItemQuantity(CartItem cartItem);

    public CartItem getCartItemById(String itemId);
}
