package org.csu.mypetstore.persistence;

import org.csu.mypetstore.domain.Category;

import java.util.List;

public interface CategoryDAO{
    //获取所有种类
    List<Category> getCategoryList();
    //根据id查看一个种类
    Category getCategory(String categoryId);
}
