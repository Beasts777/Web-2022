package org.csu.mypetstore.persistence;

import org.csu.mypetstore.domain.Product;

import java.util.List;

public interface ProductDAO {
    //根据大类ID获取产品列表
    List<Product> getProductListByCategory(String categoryId);

    //根据产品id获取产品
    Product getProduct(String productId);

    //根据关键字获取产品列表
    List<Product> searchProductList(String keywords);
}
