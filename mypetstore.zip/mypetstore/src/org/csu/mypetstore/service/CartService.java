package org.csu.mypetstore.service;

import org.csu.mypetstore.domain.*;
import org.csu.mypetstore.persistence.CartItemDAO;
import org.csu.mypetstore.persistence.impl.CartItemDAOImpl;

import java.math.BigDecimal;
import java.math.BigInteger;

public class CartService {
    private CartItemDAO cartItemDAO = new CartItemDAOImpl();

    public Cart getCartByAccount(Account account){
        Cart cart = new Cart();
        cart.addItems(cartItemDAO.getCartItemByAccount(account));
        return cart;
    }

    public void insertItem(CartItem cartItem){
        cartItemDAO.insertCartItem(cartItem);
    }

    public void increaseCartItemQuantity(CartItem cartItem){
        cartItemDAO.increaseCartItemQuantity(cartItem);
    }

    public void removeCartItem(CartItem cartItem){
        cartItemDAO.removeCartItem(cartItem);
    }

    public void updateCartItemQuantity(CartItem cartItem){
        cartItemDAO.updateCartItemQuantity(cartItem);
    }

    public static CartItem itemToCartItem(Item item,boolean inStock,int quantity,String buyername){
        CartItem cartItem = new CartItem();

        cartItem.setItemId(item.getItemId());
        cartItem.setProductId(item.getProductId());
        CatalogService catalogService = new CatalogService();
        Product product = catalogService.getProduct(item.getProductId());
        cartItem.setDescn(item.getAttr1()+ " " + product.getName());
        cartItem.setInStock(inStock);
        cartItem.setQuantity(quantity);
        cartItem.setListPrice(item.getListPrice());
        cartItem.setTotalPrice(item.getListPrice().multiply(new BigDecimal(quantity)));
        cartItem.setBuyerName(buyername);

        return cartItem;
    }

    public void clearCart(Account account){
        cartItemDAO.clearCart(account);
    }
}
