package org.csu.mypetstore.service;

import org.csu.mypetstore.domain.LineItem;
import org.csu.mypetstore.domain.Order;
import org.csu.mypetstore.domain.Sequence;
import org.csu.mypetstore.persistence.OrderDAO;
import org.csu.mypetstore.persistence.SequenceDAO;
import org.csu.mypetstore.persistence.impl.OrderDAOImpl;
import org.csu.mypetstore.persistence.impl.SequenceDAOImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderService {

    public void insertOrder(Order order) {
        OrderDAO orderDAO = new OrderDAOImpl();
        orderDAO.insertOrder(order);
    }

    public Order getOrder(int orderId) {
        OrderDAO orderDAO = new OrderDAOImpl();
        return orderDAO.getOrder(orderId);
    }

    public List<Order> getOrdersByUsername(String username) {
        OrderDAO orderDAO = new OrderDAOImpl();
        return orderDAO.getOrdersByUsername(username);
    }

    public int getNextId(String name) {
        Sequence sequence = new Sequence(name, -1);
        SequenceDAO sequenceDAO = new SequenceDAOImpl();
        sequence = (Sequence) sequenceDAO.getSequence(sequence);
        if (sequence == null) {
            throw new RuntimeException("Error: A null sequence was returned from the database (could not get next " + name
                    + " sequence).");
        }
        Sequence parameterObject = new Sequence(name, sequence.getNextId() + 1);
        sequenceDAO.updateSequence(parameterObject);
        return sequence.getNextId();
    }
}
