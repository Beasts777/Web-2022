package org.csu.mypetstore.service;

import org.csu.mypetstore.domain.AddToCartLog;
import org.csu.mypetstore.domain.UserLog;
import org.csu.mypetstore.domain.ViewItemLog;
import org.csu.mypetstore.persistence.AddToCartLogDAO;
import org.csu.mypetstore.persistence.ViewItemLogDAO;
import org.csu.mypetstore.persistence.impl.AddToCartDAOImpl;
import org.csu.mypetstore.persistence.impl.ViewItemLogDAOImpl;

import javax.swing.text.View;
import java.util.List;

public class LogService {
    private AddToCartLogDAO addToCartLogDAO;
    private ViewItemLogDAO viewItemLogDAO;

    public void insertViewLog(ViewItemLog viewItemLog){
        viewItemLogDAO = new ViewItemLogDAOImpl();
        viewItemLogDAO.insertLog(viewItemLog);
    }

    public void insertAddToCartLog(AddToCartLog addToCartLog){
        addToCartLogDAO = new AddToCartDAOImpl();
        addToCartLogDAO.insertLog(addToCartLog);
    }

    public UserLog getUserLog(String username){
        UserLog userLog = new UserLog();
        userLog.setUsername(username);
        userLog.setViewItemLogs(getViewLog(username));
        userLog.setAddToCartLogs(getCartLog(username));
        return userLog;
    }

    public List<ViewItemLog> getViewLog(String username){
        viewItemLogDAO = new ViewItemLogDAOImpl();
        return viewItemLogDAO.getLog(username);
    }

    public List<AddToCartLog> getCartLog(String username){
        addToCartLogDAO = new AddToCartDAOImpl();
        return addToCartLogDAO.getLog(username);
    }

    public void updateViewLog(String username,String itemId){
        viewItemLogDAO = new ViewItemLogDAOImpl();
        viewItemLogDAO.updateCountAndDate(username,itemId);
    }

    public void updateCartLog(String username,String itemId){
        addToCartLogDAO = new AddToCartDAOImpl();
        addToCartLogDAO.updateCountAndDate(username,itemId);
    }
}
