package org.csu.mypetstore.service;
//将DAO层获得的所有产品名字拼接为一个字符串
import org.csu.mypetstore.domain.Product;
import org.csu.mypetstore.persistence.ProductDAO;
import org.csu.mypetstore.persistence.impl.ProductDAOImpl;

import java.util.List;

public class SearchService {
    private ProductDAO productDAO;
    public SearchService(){
        productDAO=new ProductDAOImpl();
    }
    public String getItemListByProduct(String keyword)
    {
        List<Product> nameList=productDAO.searchProductList("%"+keyword+"%");
        String res="";
        for(int i=0;i< nameList.size();i++){
            if(i>0){
                res+=","+nameList.get(i).getName();
            }
            else{
                res+=nameList.get(i).getName();
            }
        }
        return res;
    }

    public String getItemListByProduct_2(String keyword){
        List<Product> nameList=productDAO.searchProductList("%"+keyword+"%");
        String res="";
        //不同个体之间用”，“连接，相同个体的名字和ID用”？“隔开
        for(int i=0;i< nameList.size();i++){
            if(i>0){
                res+=","+nameList.get(i).getName()+"?"+nameList.get(i).getCategoryId();
            }
            else{
                res+=nameList.get(i).getName()+"?"+nameList.get(i).getCategoryId();
            }
        }
        return res;
    }

    public String getProductId(String keyword)
    {
        List<Product> nameList=productDAO.searchProductList("%"+keyword+"%");
        String categoryId=nameList.get(0).getProductId();
        return categoryId;
    }
}
