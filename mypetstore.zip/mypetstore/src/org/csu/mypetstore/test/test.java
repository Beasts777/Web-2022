package org.csu.mypetstore.test;

import org.csu.mypetstore.domain.Account;
import org.csu.mypetstore.domain.Item;
import org.csu.mypetstore.domain.Product;
import org.csu.mypetstore.persistence.ItemDAO;
import org.csu.mypetstore.persistence.ProductDAO;
import org.csu.mypetstore.persistence.impl.CategoryDAOImpl;
import org.csu.mypetstore.persistence.impl.ItemDAOImpl;
import org.csu.mypetstore.persistence.impl.ProductDAOImpl;
import org.csu.mypetstore.service.AccountService;
import org.csu.mypetstore.service.CatalogService;
import org.csu.mypetstore.utils.JdbcUtils;

import javax.xml.catalog.Catalog;
import java.sql.Connection;
import java.util.List;

public class test {

//    public static void main(String[] args) {
//        AccountService service = new AccountService();
//        Account account = service.getAccount("1","1");
//        System.out.println(account);

//        CatalogService service = new CatalogService();
//
//        Item item = service.getItem("EST-1");
//        System.out.println(item);
//        List<Item> itemList = service.getItemListByProduct("RP-SN-01");
//
//
//        for (Item item : itemList) {
//            System.out.println(item);
//        }
//        List<Product> productList = service.searchProductList("a");
//
//        for (Product product : productList) {
//            System.out.println(product);
//        }

//    }

}
