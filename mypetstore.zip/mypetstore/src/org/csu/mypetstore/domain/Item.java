package org.csu.mypetstore.domain;

import java.io.Serializable;
import java.math.BigDecimal;

public class Item implements Serializable {

  private static final long serialVersionUID = -2159121673445254631L;

  private String itemId;
  private String productId;
  private BigDecimal listPrice;
  private BigDecimal unitCost;
  private int supplier;
  private String status;
  private String attr1;
  private String attr2;
  private String attr3;
  private String attr4;
  private String attr5;
  private Product product;
  private int quantity;

  public String getItemId() {
    return itemId;
  }

  public void setItemId(String itemId) {
    this.itemId = itemId.trim();
  }

  public int getQuantity() {
    return quantity;
  }

  public void setQuantity(int quantity) {
    this.quantity = quantity;
  }

  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public String getProductId() {
    return productId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public int getSupplier() {
    return supplier;
  }

  public void setSupplier(int supplier) {
    this.supplier = supplier;
  }

  public BigDecimal getListPrice() {
    return listPrice;
  }

  public void setListPrice(BigDecimal listPrice) {
    this.listPrice = listPrice;
  }

  public BigDecimal getUnitCost() {
    return unitCost;
  }

  public void setUnitCost(BigDecimal unitCost) {
    this.unitCost = unitCost;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getAttr1() {
    return attr1;
  }

  public void setAttr1(String attr1) {
    this.attr1 = attr1;
  }

  public String getAttr2() {
    return attr2;
  }

  public void setAttr2(String attr2) {
    this.attr2 = attr2;
  }

  public String getAttr3() {
    return attr3;
  }

  public void setAttr3(String attr3) {
    this.attr3 = attr3;
  }

  public String getAttr4() {
    return attr4;
  }

  public void setAttr4(String attr4) {
    this.attr4 = attr4;
  }

  public String getAttr5() {
    return attr5;
  }

  public void setAttr5(String attr5) {
    this.attr5 = attr5;
  }

  @Override
  public String toString() {
    return "Item{" +
            "itemId='" + itemId + '\'' +
            ", productId='" + productId + '\'' +
            ", listPrice=" + listPrice +
            ", unitCost=" + unitCost +
            ", supplier=" + supplier +
            ", status='" + status + '\'' +
            ", attr1='" + attr1 + '\'' +
            ", attr2='" + attr2 + '\'' +
            ", attr3='" + attr3 + '\'' +
            ", attr4='" + attr4 + '\'' +
            ", attr5='" + attr5 + '\'' +
            ", product=" + product +
            ", quantity=" + quantity +
            '}';
  }
}
