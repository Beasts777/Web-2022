package org.csu.mypetstore.domain;

import java.util.HashMap;
import java.util.List;

public class UserLog {
    private String username;
    //对item的浏览器历史和添加购物车历史
    private List<ViewItemLog> viewItemLogs;
    private List<AddToCartLog> addToCartLogs;


    public boolean containsViewLog(ViewItemLog viewItemLog){
        int len = viewItemLogs.size();
        for(int i = 0;i < len;i++){
            if(viewItemLogs.get(i).getItemId().equals(viewItemLog.getItemId()))
                return true;
        }
        return false;
    }

    public boolean containsCartLog(AddToCartLog addToCartLog){
        int len = addToCartLogs.size();
        for(int i = 0;i < len;i++){
            if(addToCartLogs.get(i).getItemId().equals(addToCartLog.getItemId()))
                return true;
        }
        return false;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public List<ViewItemLog> getViewItemLogs() {
        return viewItemLogs;
    }

    public void setViewItemLogs(List<ViewItemLog> viewItemLogs) {
        this.viewItemLogs = viewItemLogs;
    }

    public List<AddToCartLog> getAddToCartLogs() {
        return addToCartLogs;
    }

    public void setAddToCartLogs(List<AddToCartLog> addToCartLogs) {
        this.addToCartLogs = addToCartLogs;
    }
}